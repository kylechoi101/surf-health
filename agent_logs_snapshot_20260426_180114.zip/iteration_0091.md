# Iteration 91
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height anomaly relative to its 30-day mean wave height is a predictor of enterococcus exceedance, as unusual wave patterns can mobilize fecal bacteria and increase the risk of contamination.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of `wave_height_m` for each `beach_id` using a groupby operation on `beach_id` and a time window of 30 days.
* Calculate the anomaly of the current `wave_height_m` value by subtracting the 30-day rolling mean from the current value.
* Handle NaN values in the `wave_height_m` column by propagating them through the rolling mean calculation and subsequent anomaly calculation.
* Store the result in a new column `wave_height_anomaly_30d` to be used as a feature in the model.
* Consider using a robust measure of central tendency, such as the median, to reduce the impact of extreme wave height values on the rolling mean calculation.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .shift()/.diff() chains off .groupby('beach_id') for calculating the anomaly, instead it calculates the rolling mean directly which may cause cross-beach leakage if the data is not properly sorted by 'beach_id' and 'sample_date', and also does not prevent current-sample leakage in the rolling mean calculation.
```

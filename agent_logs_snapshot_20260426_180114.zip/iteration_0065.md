# Iteration 65
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_7d_cdip_buoy
HYPOTHESIS: The anomaly in wave height from its 7-day mean for a specific CDIP buoy is a predictor of enterococcus exceedance, as unusual wave conditions can mobilize and transport fecal bacteria into the water.
IMPLEMENTATION:
* Group beach_day_df by 'cdip_station_id' and calculate the 7-day rolling mean of 'wave_height_m' using `.rolling()` with `closed='left'`.
* Calculate the anomaly in wave height by subtracting the 7-day rolling mean from the current 'wave_height_m' value.
* Merge the resulting anomaly values back into beach_day_df, ensuring that each row is associated with its corresponding anomaly value.
* Use the resulting 'wave_height_anomaly_7d_cdip_buoy' feature as a predictor in the model, capturing the impact of unusual wave conditions on enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' when calculating the rolling mean, which can cause cross-beach leakage.
```

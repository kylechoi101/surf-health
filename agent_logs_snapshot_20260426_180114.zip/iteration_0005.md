# Iteration 5
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_exceedance_ratio
HYPOTHESIS: The ratio of days with high wave activity to the total number of days in a given time window is a predictor of enterococcus exceedance, as prolonged periods of high wave activity can increase the mobilization and transport of fecal bacteria to the beach.
IMPLEMENTATION:
* Filter beach_day_df to only include rows where wave_height_m is greater than a certain threshold (e.g. 2 meters) and calculate the number of such days in a 30-day window.
* Calculate the total number of days in the same 30-day window, excluding days with missing wave_height_m values.
* Compute the ratio of high wave activity days to total days in the window for each beach, using the sample_date column to determine the relevant time window for each row.
* Use the rolling function to apply this calculation to each row in beach_day_df, ensuring that only data from previous days is used to avoid leaking future data.
* Merge the resulting ratio values back into beach_day_df, creating a new column that can be used as a feature in the model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .shift()/.diff() chains off .groupby('beach_id') and also does not follow the exact .rolling() syntax to prevent cross-beach leakage.
```

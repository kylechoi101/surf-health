# Iteration 22
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: precip_wave_height_interaction_7d
HYPOTHESIS: The interaction between precipitation and wave height over the past 7 days can indicate increased mobilization of fecal bacteria, leading to enterococcus exceedance, as heavy rain and strong waves together can resuspend and transport more bacteria into the water.
IMPLEMENTATION:
* Calculate the 7-day rolling sum of precip_mm_6h, precip_mm_24h, precip_mm_48h, and precip_mm_72h to get the total precipitation over the past week.
* Calculate the 7-day rolling mean of wave_height_m to get the average wave height over the past week.
* Multiply the total precipitation and average wave height to get the interaction term, using the rolling sum and mean calculated in the previous steps.
* Use the resulting interaction term as a feature, which can be computed for each row in beach_day_df without leaking future data.
* Consider using a logarithmic transformation of the interaction term to reduce the impact of extreme values and improve model stability.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the rule of selecting a column before calling rolling on a groupby object for the sum operation.
```

# Iteration 55
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_30d_mean

HYPOTHESIS: The deviation of the current wave height from the 30-day mean wave height at the same CDIP buoy can predict enterococcus exceedance, as unusually high waves may mobilize and transport fecal bacteria to the beach.

IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy, using the cdip_station_id to group the data.
* Compute the deviation of the current wave_height_m from this 30-day mean, using a pandas merge to align the current wave height with its corresponding 30-day mean.
* Handle NaN values in wave_height_m by propagating them through the calculation, ensuring that the resulting feature is also NaN when the input data is missing.
* Use the .shift() method to ensure that the 30-day mean is calculated only from past data, avoiding information leakage.
* Store the result in a new column, wave_height_deviation_from_30d_mean, which can be used as a feature in the enterococcus exceedance model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage because it does not use .shift()/.diff() chains off .groupby('beach_id') and does not correctly apply the rolling function to prevent leakage, specifically it groups by 'cdip_station_id' instead of 'beach_id'.
```

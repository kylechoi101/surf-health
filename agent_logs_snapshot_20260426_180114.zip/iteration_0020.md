# Iteration 20
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: cdip_buoy_wave_height_anomaly_14d
HYPOTHESIS: A beach's current wave height exceeding its 14-day average wave height at the nearest CDIP buoy is likely to increase the mobilization of fecal bacteria, leading to a higher enterococcus exceedance rate.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each beach, grouped by the cdip_station_id to account for shared buoys across a region.
* Calculate the difference between the current wave_height_m and the 14-day rolling mean for each beach.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation, ensuring that the resulting anomaly is also NaN when the wave height is missing.
* Use the resulting anomaly as a feature, allowing the model to capture the impact of wave height changes on enterococcus exceedance rates.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' when calculating the rolling mean and difference, which can cause cross-beach leakage.
```

# Iteration 59
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_30d_mean
HYPOTHESIS: The deviation of the current wave height from the 30-day mean wave height at each beach's nearest CDIP buoy can predict enterococcus exceedance, as unusual wave patterns may mobilize fecal bacteria in the water.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using `.groupby('beach_id').rolling('30D', closed='left')`.
* Compute the deviation of the current wave_height_m from this 30-day mean for each row in beach_day_df.
* Handle NaN values in wave_height_m by using `.fillna()` or `.interpolate()` to ensure the feature is computable for all rows.
* Consider using `.shift()` or `.diff()` chains to prevent information leakage and ensure the feature is based on past data only.
---
## Code
*No code generated.*

---
## Errors
```
EXEC: Runtime error: ValueError: window must be an integer 0 or greater
ile "/Users/kylechoi/surf_health/backend/.venv/lib/python3.12/site-packages/pandas/core/window/rolling.py", line 160, in __init__
    self._validate()
  File "/Users/kylechoi/surf_health/backend/.venv/lib/python3.12/site-packages/pandas/core/window/rolling.py", line 2022, in _validate
    raise ValueError("window must be an integer 0 or greater")
ValueError: window must be an integer 0 or greater

```

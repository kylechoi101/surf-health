# Iteration 2
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_dominant_period_ratio_anomaly
HYPOTHESIS: The anomaly in the ratio of wave height to dominant period, compared to the historical average for that CDIP buoy, can predict enterococcus exceedance by indicating changes in wave energy and potential for sediment resuspension.
IMPLEMENTATION:
* Calculate the ratio of wave_height_m to dominant_period_s for each row in beach_day_df.
* Compute the 30-day moving average of this ratio for each CDIP buoy, using cdip_station_id to group the data.
* Calculate the anomaly of the current ratio from the 30-day moving average for each row in beach_day_df.
* Scale the anomaly by the standard deviation of the ratio for each CDIP buoy, to account for differences in wave climate between buoys.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' when applying rolling window operations, which can cause cross-beach leakage.
```

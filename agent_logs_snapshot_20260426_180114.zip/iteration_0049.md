# Iteration 49
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.1783 | AUCPR: 0.5099 | Brier: 0.0720

---
## Idea
FEATURE NAME: wave_height_to_streamflow_ratio
HYPOTHESIS: The ratio of wave height to streamflow can indicate the relative contribution of oceanic and terrestrial sources of fecal bacteria, with higher ratios potentially indicating a greater oceanic influence and lower ratios indicating a greater terrestrial influence, which can predict enterococcus exceedance.
IMPLEMENTATION:
* Calculate the rolling 7-day mean of streamflow_cfs_latest for each beach, using `beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].transform(lambda x: x.rolling(7, min_periods=1, closed='left').mean())`.
* Calculate the rolling 7-day mean of wave_height_m for each beach, using `beach_day_df.groupby('beach_id')['wave_height_m'].transform(lambda x: x.rolling(7, min_periods=1, closed='left').mean())`.
* Compute the ratio of wave height to streamflow for each sample, using `wave_height_m_7d_mean / streamflow_cfs_latest_7d_mean`, handling NaN values by using `fillna` or `ffill` methods.
* Multiply the ratio by a binary flag indicating whether the streamflow is rising (streamflow_rising_flag), to capture the potential increased risk of enterococcus exceedance during rising streamflow events.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the rolling 7-day mean of streamflow_cfs_latest for each beach
    beach_day_df['streamflow_cfs_latest_7d_mean'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].rolling(7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the rolling 7-day mean of wave_height_m for each beach
    beach_day_df['wave_height_m_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the wave height to streamflow ratio
    beach_day_df['wave_height_to_streamflow_ratio'] = np.log1p(beach_day_df['wave_height_m_7d_mean'] / (beach_day_df['streamflow_cfs_latest_7d_mean'] + 1e-9))
    
    # Return a DataFrame with columns: beach_id, sample_date, wave_height_to_streamflow_ratio
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_to_streamflow_ratio']]
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5099)
```

# Iteration 8
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_7d_buoy_relative
HYPOTHESIS: A beach's current wave height compared to the 7-day average wave height of its nearest CDIP buoy can indicate increased mobilization of fecal bacteria, leading to a higher likelihood of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of wave_height_m for each CDIP buoy, grouping by cdip_station_id in beach_day_df.
* Merge this rolling mean with the original beach_day_df, matching on cdip_station_id and sample_date.
* Calculate the anomaly as the difference between the current wave_height_m and the 7-day rolling mean for that buoy.
* Use this anomaly as the new feature, wave_height_anomaly_7d_buoy_relative, which can be used to predict enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage because it groups by 'cdip_station_id' when calculating the rolling mean, but it should also consider the 'beach_id' to get the correct wave height for each beach, however, the correct fix is to group by both 'beach_id' and 'cdip_station_id' or just 'cdip_station_id' if 'cdip_station_id' is unique for each beach.
```

# Iteration 73
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_salinity_interaction_7d
HYPOTHESIS: The interaction between a beach's current wave height and its 7-day average salinity can indicate an increased risk of enterococcus exceedance due to the mobilization of fecal bacteria by unusual wave and salinity conditions.
IMPLEMENTATION:
* Calculate the 7-day rolling average of salinity_psu for each beach, using `.rolling()` with `closed='left'` to avoid information leakage.
* Calculate the current wave height anomaly by subtracting the 30-day rolling average of wave_height_m from the current wave_height_m value.
* Multiply the current wave height anomaly by the 7-day rolling average of salinity_psu to create the interaction term.
* Use `.groupby()` on beach_id to ensure that the rolling averages and interactions are calculated separately for each beach.
* Use `.shift()` to align the interaction term with the sample_date, ensuring that the feature does not leak future data.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not check if advisories_df and stations_df have the required columns, and it does not handle potential errors for these DataFrames.
```

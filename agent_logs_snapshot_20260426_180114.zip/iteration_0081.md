# Iteration 81
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: A beach's current wave height deviating from the 30-day average wave height of its corresponding CDIP buoy is a predictor of enterococcus exceedance, as unusual wave patterns can disrupt normal water circulation and increase the likelihood of bacterial contamination.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy using the cdip_station_id column to group the data.
* Merge the beach_day_df with the buoy means to get the mean wave height for the corresponding buoy for each beach sample.
* Calculate the deviation of the current wave height from the buoy mean for each sample.
* Handle NaN values in wave_height_m by using a suitable imputation method, such as forward or backward filling, to avoid introducing bias into the feature.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the critical rule of using .rolling() chained exactly after selecting a column from a groupby object, and it also does not use .shift()/.diff() chains off .groupby('beach_id').
```

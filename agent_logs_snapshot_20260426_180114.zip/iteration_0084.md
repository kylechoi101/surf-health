# Iteration 84
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: The deviation of current wave height from the long-term mean for the corresponding CDIP buoy can indicate increased mobilization of fecal bacteria, leading to enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy (using cdip_station_id to group) and merge this back into beach_day_df.
* Calculate the difference between the current wave_height_m and the corresponding buoy's 30-day mean, handling NaN values by propagating them through the calculation.
* Use this difference as the new feature, wave_height_deviation_from_buoy_mean, which captures the anomaly in wave height relative to the typical conditions for that buoy.
* Consider using a robust measure of central tendency, such as the median, to reduce the impact of extreme wave height values on the calculation.
* Ensure that the rolling mean calculation uses a time window that does not leak future data, by using .shift() or .rolling() with appropriate parameters to exclude future values.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the critical rule of chaining window functions off .groupby('beach_id'), instead it groups by 'cdip_station_id'.
```

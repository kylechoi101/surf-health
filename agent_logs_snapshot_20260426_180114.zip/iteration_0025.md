# Iteration 25
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2516 | AUCPR: 0.5102 | Brier: 0.0720

---
## Idea
FEATURE NAME: wave_height_anomaly_14d
HYPOTHESIS: The anomaly in wave height over the past 14 days, compared to the typical wave height for that beach, can predict enterococcus exceedance by indicating unusual ocean conditions that may mobilize fecal bacteria.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each beach, using `.groupby('beach_id').rolling(14, closed='left')` to avoid information leakage.
* Compute the anomaly in wave height by subtracting the 14-day rolling mean from the current wave_height_m value, resulting in a new column wave_height_anomaly_14d.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation, ensuring that the anomaly is also NaN when the wave height is missing.
* Use the resulting wave_height_anomaly_14d feature as a predictor of enterococcus exceedance, capturing the impact of unusual wave conditions on beach water quality.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    """
    This function engineers a novel beach water-quality feature, wave_height_anomaly_14d.
    It calculates the anomaly in wave height over the past 14 days, compared to the typical wave height for that beach.
    
    Parameters:
    beach_day_df (DataFrame): A DataFrame containing beach day data.
    advisories_df (DataFrame): A DataFrame containing advisories data.
    stations_df (DataFrame): A DataFrame containing stations data.
    
    Returns:
    DataFrame: A DataFrame with columns: beach_id, sample_date, wave_height_anomaly_14d.
    """
    
    # Calculate the 14-day rolling mean of wave_height_m for each beach
    beach_day_df['wave_height_m_14d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(14, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the anomaly in wave height by subtracting the 14-day rolling mean from the current wave_height_m value
    beach_day_df['wave_height_anomaly_14d'] = beach_day_df['wave_height_m'] - beach_day_df['wave_height_m_14d_mean']
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_anomaly_14d']]
    
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5102)
```

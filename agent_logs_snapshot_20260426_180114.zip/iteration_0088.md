# Iteration 88
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: streamflow_wave_height_interaction
HYPOTHESIS: The interaction between streamflow and wave height can predict enterococcus exceedance, as increased streamflow and wave height together may mobilize and transport fecal bacteria into the ocean.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach_id in beach_day_df.
* Calculate the 7-day rolling mean of wave_height_m for each cdip_station_id in beach_day_df.
* Merge the two rolling mean calculations on beach_day_df to create a new dataframe with the streamflow and wave height means.
* Calculate the interaction term between the streamflow and wave height means by multiplying the two values together, creating a new feature that captures the combined effect of streamflow and wave height on enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the advisories_df DataFrame and does not follow the critical rules for pandas as it uses .rolling() directly on a groupby object without selecting a specific column first in a way that could potentially cause cross-beach leakage, and also returns more than one new column before the final selection.
```

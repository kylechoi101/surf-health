# Iteration 29
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height exceeding its 30-day average wave height is likely to mobilize fecal bacteria and increase the risk of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using .groupby('beach_id') and .rolling('30D', closed='left') on the sample_date index.
* Compute the wave height anomaly as the difference between the current wave_height_m and the 30-day rolling mean.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation and resulting anomaly values.
* Store the resulting wave height anomaly values in a new column, wave_height_anomaly_30d, which can be used as a feature to predict enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the exact chaining rule for window functions, using .rolling() directly on the grouped column instead of selecting a column first and then applying .rolling().
```

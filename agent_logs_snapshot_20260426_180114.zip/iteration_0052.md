# Iteration 52
**Status:** FAILED (correlation gate)

---
## Idea
FEATURE NAME: wave_height_to_salinity_ratio
HYPOTHESIS: The ratio of wave height to salinity can indicate the relative influence of oceanic and terrestrial sources of fecal bacteria, with higher ratios potentially indicating a greater oceanic influence and lower ratios indicating a greater terrestrial influence.
IMPLEMENTATION:
* Calculate the rolling 7-day mean of wave_height_m for each beach_id using `.groupby()` and `.rolling()` with `closed='left'`.
* Calculate the rolling 7-day mean of salinity_psu for each beach_id using `.groupby()` and `.rolling()` with `closed='left'`.
* Compute the ratio of the two rolling means, handling NaN values by using `.fillna()` or `.dropna()` as necessary, and assign the result to a new column in beach_day_df.
* Consider using `.shift()` to align the ratio with the sample_date, ensuring that the ratio is computed from data prior to the enterococcus measurement.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the rolling 7-day mean of wave_height_m for each beach_id
    beach_day_df['wave_height_m_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the rolling 7-day mean of salinity_psu for each beach_id
    beach_day_df['salinity_psu_7d_mean'] = beach_day_df.groupby('beach_id')['salinity_psu'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the ratio of the two rolling means, handling NaN values
    beach_day_df['wave_height_to_salinity_ratio'] = beach_day_df['wave_height_m_7d_mean'] / (beach_day_df['salinity_psu_7d_mean'] + 1e-9)
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_to_salinity_ratio']].copy()
    
    return result_df
```

---
## Errors
```
High correlation (0.94) with existing features — redundant.
```

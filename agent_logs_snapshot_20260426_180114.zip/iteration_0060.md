# Iteration 60
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_from_buoy_mean
HYPOTHESIS: The anomaly of the current wave height from the mean wave height at each beach's nearest CDIP buoy can predict enterococcus exceedance, as unusual wave patterns may mobilize fecal bacteria in the water.
IMPLEMENTATION:
* Calculate the 30-day mean wave height for each CDIP buoy using the `wave_height_m` column and a `.groupby()` operation on `cdip_station_id` and a `.rolling()` window with a 30-day period.
* Compute the anomaly of the current wave height from the buoy mean by subtracting the 30-day mean from the current `wave_height_m` value for each row in `beach_day_df`.
* Handle missing `wave_height_m` values by using a forward or backward fill strategy to avoid propagating NaN values in the anomaly calculation.
* Scale the anomaly values to have zero mean and unit variance within each CDIP buoy group to reduce the impact of varying wave height scales across buoys.
* Merge the resulting anomaly values back into `beach_day_df` to create the new feature.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the critical rules for pandas, specifically it uses .rolling() directly on a groupby object without selecting a specific column first in the line where it calculates the 30-day mean wave height, and also it does not chain .rolling() off .groupby('beach_id') as required to prevent cross-beach leakage.
```

# Iteration 24
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: streamflow_spike_ratio_24h
HYPOTHESIS: A high ratio of the latest streamflow to the 24-hour mean streamflow indicates a sudden surge in water flow, which can mobilize fecal bacteria and lead to enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 24-hour rolling mean of streamflow_cfs_latest for each beach using `.groupby('beach_id').rolling('24h', closed='left')`.
* Compute the ratio of the latest streamflow_cfs_latest to the 24-hour mean streamflow for each beach.
* Handle NaN values in streamflow_cfs_latest by using `.fillna` with a suitable replacement value, such as the 24-hour mean streamflow.
* Use the `.shift` method to ensure that the 24-hour mean streamflow is calculated only up to the current sample date, avoiding information leakage.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the provided advisories_df and stations_df, and it incorrectly calls rolling on a groupby object without selecting a column first, then incorrectly uses shift on the result of groupby without selecting a column first, and also does not follow the rule of selecting a column before calling rolling and shift.
```

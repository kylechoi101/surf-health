# Iteration 15
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: A beach's current wave height deviating significantly from the mean wave height of its corresponding CDIP buoy over a 30-day window may indicate an increased risk of enterococcus exceedance due to the mobilization of fecal bacteria by unusual wave patterns.
IMPLEMENTATION:
* Calculate the 30-day mean wave height for each CDIP buoy using the `wave_height_m` column in `beach_day_df` and grouping by `cdip_station_id`.
* Compute the deviation of the current wave height from the 30-day mean wave height for each beach using the `wave_height_m` column in `beach_day_df` and the calculated mean wave height for each CDIP buoy.
* Use the `.shift()` and `.rolling()` functions with `closed='left'` to ensure that the calculation only uses past data and does not leak future information.
* Handle missing values in the `wave_height_m` column by using a suitable imputation method, such as using the mean wave height for the corresponding CDIP buoy, to avoid biased calculations.
* Store the calculated deviation in a new column in `beach_day_df` to use as a feature in the model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' before applying the rolling function, which can cause cross-beach leakage, and also does not use the advisories_df parameter.
```

# Iteration 14
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: streamflow_spike_ratio_24h
HYPOTHESIS: A sudden increase in streamflow, measured as the ratio of the latest 24-hour streamflow to the mean 24-hour streamflow over the past 30 days, may indicate an increased risk of enterococcus exceedance due to the rapid mobilization of fecal bacteria from land-based sources.
IMPLEMENTATION:
* Calculate the 30-day mean 24-hour streamflow for each beach using the `streamflow_cfs_mean_24h` column and a rolling window of 30 days with `closed='left'`.
* Calculate the latest 24-hour streamflow for each beach using the `streamflow_cfs_latest` column.
* Compute the streamflow spike ratio as the ratio of the latest 24-hour streamflow to the 30-day mean 24-hour streamflow.
* Handle NaN values in the `streamflow_cfs_latest` and `streamflow_cfs_mean_24h` columns by propagating them to the resulting feature, ensuring that missing values do not affect the calculation.
* Use the `groupby` method to compute the feature separately for each beach, using the `beach_id` column as the grouping variable.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not correctly calculate the 'streamflow_cfs_latest' column and does not use .shift()/.diff() chains off .groupby('beach_id') as required, and also does not verify the existence of 'streamflow_cfs_latest' column in the beach_day_df.
```

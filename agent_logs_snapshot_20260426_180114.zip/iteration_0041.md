# Iteration 41
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating significantly from its 30-day average is likely to mobilize fecal bacteria, increasing the risk of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using `.groupby('beach_id').rolling('30D', closed='left')`.
* Compute the difference between the current wave_height_m and the 30-day rolling mean for each beach_id.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation and difference computation.
* Use the resulting wave height anomaly as a feature, which can be used to identify periods of unusually high or low wave activity that may contribute to enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function uses .rolling() with a string window ('30D') which is not an integer, causing a ValueError, and does not follow the required format for .rolling() which should be an integer.
```

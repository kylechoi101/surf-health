# Iteration 92
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_7d_by_buoy
HYPOTHESIS: A beach's current wave height anomaly relative to its 7-day mean wave height, calculated separately for each CDIP buoy, is a predictor of enterococcus exceedance, as unusual wave patterns from a specific buoy can mobilize fecal bacteria and increase the risk of contamination.
IMPLEMENTATION:
* Group beach_day_df by cdip_station_id and calculate the 7-day rolling mean of wave_height_m for each group.
* Calculate the anomaly of wave_height_m for each row by subtracting the corresponding 7-day rolling mean.
* Store the result in a new column, wave_height_anomaly_7d_by_buoy, which represents the deviation of the current wave height from the recent mean wave height for that specific CDIP buoy.
* Ensure that the calculation does not leak future data by using a rolling window that only includes past data up to the current sample date.
* Handle NaN values in wave_height_m by propagating them through the calculation, so that NaN values in the input result in NaN values in the output.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' when calculating the rolling mean, which can cause cross-beach leakage.
```

# Iteration 56
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.1744 | AUCPR: 0.5093 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_to_streamflow_ratio
HYPOTHESIS: The ratio of wave height to streamflow can predict enterococcus exceedance, as high wave heights combined with low streamflow may indicate a lack of flushing of pollutants from the beach, while high streamflow with low wave heights may indicate a high influx of pollutants from land-based sources.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach_id using `.groupby()` and `.rolling()` with `closed='left'`.
* Calculate the wave height average for each beach_id using the wave_height_m column.
* Compute the ratio of wave height to streamflow by dividing the wave height average by the 7-day rolling mean streamflow for each beach_id.
* Use the `.shift()` function to ensure that the streamflow values used in the calculation are from the previous 7 days, avoiding any potential information leakage.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach_id
    beach_day_df['streamflow_cfs_latest_7d_mean'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the wave height average for each beach_id
    beach_day_df['wave_height_m_avg'] = beach_day_df.groupby('beach_id')['wave_height_m'].transform('mean')
    
    # Compute the ratio of wave height to streamflow by dividing the wave height average by the 7-day rolling mean streamflow for each beach_id
    beach_day_df['wave_height_to_streamflow_ratio'] = np.log1p(beach_day_df['wave_height_m_avg'] / (beach_day_df['streamflow_cfs_latest_7d_mean'] + 1e-9))
    
    # Shift the streamflow value to ensure that the streamflow value is from the previous sample
    beach_day_df['streamflow_cfs_latest_7d_mean_shifted'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest_7d_mean'].shift(1)
    
    # Recalculate the ratio using the shifted streamflow value
    beach_day_df['wave_height_to_streamflow_ratio_shifted'] = np.log1p(beach_day_df['wave_height_m_avg'] / (beach_day_df['streamflow_cfs_latest_7d_mean_shifted'] + 1e-9))
    
    # Return a DataFrame with columns: beach_id, sample_date, wave_height_to_streamflow_ratio_shifted
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_to_streamflow_ratio_shifted']].rename(columns={'wave_height_to_streamflow_ratio_shifted': 'wave_height_to_streamflow_ratio'})
```

---
## Errors
```
Degrades CV AUCPR (0.5107 → 0.5093)
```

# Iteration 83
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: The deviation of current wave height from the 30-day mean for the corresponding CDIP buoy can indicate increased mobilization of fecal bacteria, leading to enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy (cdip_station_id) using beach_day_df, ensuring to handle NaN values properly.
* Compute the anomaly by subtracting the 30-day rolling mean from the current wave_height_m for each row in beach_day_df.
* Use the groupby operation on cdip_station_id to ensure that the rolling mean is calculated separately for each buoy, avoiding cross-beach leakage.
* Merge the resulting anomaly values back into beach_day_df, allowing for the creation of a new feature that captures the deviation of current wave height from the recent mean.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage because it groups by 'cdip_station_id' instead of 'beach_id' when calculating the rolling mean.
```

# Iteration 45
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: The anomaly of the current wave height from its 30-day mean at the specific CDIP buoy is likely to predict enterococcus exceedance, as unusually high waves may mobilize fecal bacteria from the surrounding environment.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy (identified by cdip_station_id) using `.groupby()` and `.rolling()`.
* Compute the difference between the current wave_height_m and the corresponding 30-day rolling mean to obtain the wave height anomaly.
* Handle NaN values in wave_height_m by using `.fillna()` or `.interpolate()` to avoid propagating missing values to the anomaly calculation.
* Store the resulting wave height anomaly in a new column, wave_height_anomaly_30d, to be used as a predictive feature.
---
## Code
*No code generated.*

---
## Errors
```
AST FAILED: .apply() is forbidden. It runs Python per-row/group and causes timeouts. Use vectorized pandas operations.
```

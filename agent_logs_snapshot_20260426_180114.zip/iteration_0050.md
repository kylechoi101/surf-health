# Iteration 50
**Status:** FAILED (correlation gate)

---
## Idea
FEATURE NAME: wave_height_to_salinity_ratio
HYPOTHESIS: The ratio of wave height to salinity can indicate the relative influence of freshwater and marine sources on enterococcus levels, with higher ratios potentially indicating a greater marine influence and lower ratios indicating a greater freshwater influence.
IMPLEMENTATION:
* Calculate the rolling 7-day mean of wave_height_m for each beach, using .groupby('beach_id') and .rolling('7D') with a closed='left' window to avoid information leakage.
* Calculate the rolling 7-day mean of salinity_psu for each beach, using .groupby('beach_id') and .rolling('7D') with a closed='left' window to avoid information leakage.
* Compute the ratio of wave_height_m to salinity_psu for each row, using the rolling means calculated in the previous steps.
* Handle missing values in wave_height_m and salinity_psu by using .fillna() or .interpolate() methods to ensure that the ratio calculation is robust to missing data.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the rolling 7-day mean of wave_height_m for each beach
    beach_day_df['wave_height_m_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the rolling 7-day mean of salinity_psu for each beach
    beach_day_df['salinity_psu_7d_mean'] = beach_day_df.groupby('beach_id')['salinity_psu'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the ratio of wave_height_m to salinity_psu for each row
    beach_day_df['wave_height_to_salinity_ratio'] = beach_day_df['wave_height_m_7d_mean'] / (beach_day_df['salinity_psu_7d_mean'] + 1e-9)
    
    # Return a DataFrame with columns: beach_id, sample_date, wave_height_to_salinity_ratio
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_to_salinity_ratio']]
```

---
## Errors
```
High correlation (0.94) with existing features — redundant.
```

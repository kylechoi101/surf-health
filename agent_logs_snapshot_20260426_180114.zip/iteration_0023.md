# Iteration 23
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_14d_by_buoy
HYPOTHESIS: The deviation of current wave height from the 14-day average wave height for the specific CDIP buoy associated with each beach can indicate increased mobilization of fecal bacteria, leading to enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each CDIP buoy, using the cdip_station_id to group the data.
* Compute the anomaly as the difference between the current wave_height_m and the corresponding 14-day rolling mean.
* Use the .shift() function to ensure that the rolling mean only includes data up to the current sample date, avoiding information leakage.
* Store the result in a new column, using the beach_id and sample_date to align with the existing data.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .groupby('beach_id') for rolling calculation, instead it uses .groupby('cdip_station_id'), which may cause cross-beach leakage.
```

# Iteration 58
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_from_dominant_period
HYPOTHESIS: The anomaly of the current wave height from the wave height predicted by the dominant period at the same CDIP buoy can predict enterococcus exceedance, as unusually high waves relative to the dominant period may mobilize and transport fecal bacteria to the beach.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy using beach_day_df and groupby on cdip_station_id
* Calculate the 30-day rolling mean of dominant_period_s for each CDIP buoy using beach_day_df and groupby on cdip_station_id
* Compute the predicted wave height based on the dominant period using a linear regression model on the rolling means of wave_height_m and dominant_period_s
* Calculate the anomaly of the current wave height from the predicted wave height as a new feature in beach_day_df
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the critical rules for pandas, specifically it uses `groupby` followed by `rolling` without selecting a column first in the line where `predicted_wave_height` is calculated, and also uses `groupby` followed by `mean` without selecting a column first.
```

# Iteration 13
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating significantly from its 30-day average wave height, as measured by the nearest CDIP buoy, may indicate an increased risk of enterococcus exceedance due to the mobilization of fecal bacteria by unusual wave activity.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of `wave_height_m` for each beach using `.groupby('beach_id').rolling('30D', closed='left')`.
* Subtract the rolling mean from the current `wave_height_m` value to obtain the wave height anomaly for each sample.
* Use `.groupby('beach_id').apply()` to ensure the calculation is performed separately for each beach, avoiding cross-beach leakage.
* Store the resulting anomaly values in a new column, allowing for further analysis and potential inclusion in the predictive model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .shift()/.diff() chains off .groupby('beach_id') as required, instead it uses .rolling() directly on the grouped column, which does not meet the requirement of using .shift() or .diff() at all.
```

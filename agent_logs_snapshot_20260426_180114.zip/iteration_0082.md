# Iteration 82
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: A beach's current wave height deviating from the 30-day average wave height of its corresponding CDIP buoy is a predictor of enterococcus exceedance, as unusual wave patterns can disrupt normal water circulation and increase the likelihood of bacterial contamination.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy (identified by cdip_station_id) using `.groupby()` and `.rolling()` with `closed='left'`.
* Merge the resulting buoy-mean wave heights with beach_day_df on cdip_station_id and sample_date to get the mean wave height for each beach's corresponding buoy at each sample date.
* Calculate the deviation of wave_height_m from the buoy-mean wave height at each sample date using simple subtraction.
* Handle NaN values in wave_height_m by propagating them through the calculation, ensuring that the resulting feature is also NaN when wave_height_m is missing.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage because it groups by 'cdip_station_id' when calculating the rolling mean of wave_height_m but does not properly handle the index after the groupby operation, and also does not use the correct column to group by to prevent leakage. 

However, upon closer inspection, the issue seems to be that the function is not using the correct groupby operation to prevent cross-beach leakage. The correct column to group by should be 'beach_id', not 'cdip_station_id'. 

Here is the corrected code:
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Merge beach_day_df with stations_df to get cdip_station_id
    merged_df = pd.merge(beach_day_df, stations_df[['beach_id', 'cdip_station_id']], on='beach_id')
    
    # Calculate the 30-day rolling mean of wave_height_m for each beach
    merged_df['buoy_mean_wave_height'] = merged_df.groupby('beach_id')['wave_height_m'].rolling(window=30, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the deviation of wave_height_m from the buoy-mean wave height
    merged_df['wave_height_deviation_from_buoy_mean'] = merged_df['wave_height_m'] - merged_df['buoy_mean_wave_height']
    
    # Return a DataFrame with columns: beach_id, sample_date, wave_height_deviation_from_buoy_mean
    return merged_df[['beach_id', 'sample_date', 'wave_height_deviation_from_buoy_mean']]
```
```

# Iteration 17
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height exceeding its 30-day average wave height is likely to increase the mobilization of fecal bacteria, leading to a higher enterococcus exceedance rate.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using `.groupby()` and `.rolling()` with `closed='left'` to avoid information leakage.
* Compute the difference between the current wave_height_m and the 30-day rolling mean, handling NaN values in wave_height_m by propagating them through the calculation.
* Use `.shift()` to align the rolling mean with the current wave_height_m, ensuring that the anomaly is calculated relative to the preceding 30-day period.
* Store the result in a new column, wave_height_anomaly_30d, which will be used as a predictive feature in the model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the advisories_df and stations_df parameters, and the .shift(0) operation does not change the values in the 'wave_height_anomaly_30d' column, which seems unnecessary.
```

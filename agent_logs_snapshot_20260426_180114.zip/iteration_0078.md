# Iteration 78
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: precip_wave_height_interaction_7d
HYPOTHESIS: The interaction between precipitation and wave height over the past 7 days is indicative of increased enterococcus exceedance due to the mobilization of fecal bacteria by combined rain and swell activity.
IMPLEMENTATION:
* Calculate the 7-day rolling sum of precip_mm_6h, precip_mm_24h, precip_mm_48h, and precip_mm_72h to obtain the total precipitation over the past 7 days.
* Calculate the 7-day rolling mean of wave_height_m to obtain the average wave height over the past 7 days.
* Multiply the total precipitation and average wave height to obtain the interaction term, handling NaN values in wave_height_m by propagating them to the interaction term.
* Use the resulting interaction term as the novel feature, allowing for the capture of combined effects of rain and swell on enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function returns more than one new column and does not follow the critical rules for pandas because it does not select a column before calling rolling on a groupby object with multiple columns, and also returns multiple new columns instead of one.
```

# Iteration 80
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_salinity_interaction
HYPOTHESIS: The interaction between wave height and salinity can predict enterococcus exceedance, as unusual wave patterns and changes in salinity can disrupt normal water circulation and increase the likelihood of bacterial contamination.
IMPLEMENTATION:
* Calculate the 7-day rolling average of wave height for each beach using the `wave_height_m` column and `.rolling()` function with `closed='left'`.
* Calculate the 7-day rolling average of salinity for each beach using the `salinity_psu` column and `.rolling()` function with `closed='left'`.
* Multiply the rolling averages of wave height and salinity to create an interaction term, which will be used as the novel feature.
* Handle missing values in the `wave_height_m` and `salinity_psu` columns by using the `.fillna()` method to replace NaN values with the rolling average of the respective column, ensuring that the interaction term is calculable for all samples.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the provided advisories_df and stations_df DataFrames, and it also does not handle potential division by zero errors, and it uses .add() to handle missing values which can be replaced with vectorized operations, and it does not follow the critical rules for pandas as it does not select a column before calling rolling on a groupby object.
```

# Iteration 86
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: The deviation of current wave height from the long-term mean for the corresponding CDIP buoy can indicate increased mobilization of fecal bacteria, leading to enterococcus exceedance.
IMPLEMENTATION:
* Calculate the mean wave height for each CDIP buoy using the `wave_height_m` column from `beach_day_df`, grouped by `cdip_station_id` from `stations_df`.
* Merge this mean wave height with `beach_day_df` based on `cdip_station_id` to create a new column `buoy_mean_wave_height`.
* Calculate the deviation of current wave height from the buoy mean by subtracting `buoy_mean_wave_height` from `wave_height_m` and store this in a new column `wave_height_deviation`.
* Handle NaN values in `wave_height_m` by propagating them to `wave_height_deviation` to avoid introducing bias.
---
## Code
*No code generated.*

---
## Errors
```
AST FAILED: .apply() is forbidden. It runs Python per-row/group and causes timeouts. Use vectorized pandas operations.
```

# Iteration 48
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2006 | AUCPR: 0.5097 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_salinity_interaction
HYPOTHESIS: The interaction between wave height and salinity is likely to predict enterococcus exceedance, as high wave energy combined with low salinity may mobilize fecal bacteria from the surrounding environment and reduce the dilution of pollutants.
IMPLEMENTATION:
* Calculate the product of wave_height_m and salinity_psu for each row in beach_day_df to capture the interaction between these two variables.
* Use the .groupby() function to group the data by beach_id and calculate the rolling mean of this interaction over a 7-day window to account for temporal variations.
* Use the .shift() function to shift the resulting values back by one day to ensure that the feature is computable without leaking future data.
* Handle NaN values in wave_height_m by using the .fillna() function to replace them with the mean wave height for each beach, calculated over a 30-day window.
* Scale the resulting values using the .std() and .mean() functions to reduce the impact of outliers and improve model interpretability.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the product of wave_height_m and salinity_psu
    beach_day_df['wave_height_salinity_interaction'] = beach_day_df['wave_height_m'] * beach_day_df['salinity_psu']

    # Group by beach_id and calculate the rolling mean of the interaction over a 7-day window
    beach_day_df['wave_height_salinity_interaction_rolling_mean'] = beach_day_df.groupby('beach_id')['wave_height_salinity_interaction'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Shift the resulting values back by one day
    beach_day_df['wave_height_salinity_interaction_rolling_mean_shifted'] = beach_day_df.groupby('beach_id')['wave_height_salinity_interaction_rolling_mean'].shift(1)

    # Handle NaN values
    beach_day_df['wave_height_salinity_interaction_rolling_mean_shifted'] = beach_day_df['wave_height_salinity_interaction_rolling_mean_shifted'].fillna(0)

    # Return a DataFrame with columns: beach_id, sample_date, and the new feature column
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_salinity_interaction_rolling_mean_shifted']].rename(columns={'wave_height_salinity_interaction_rolling_mean_shifted': 'wave_height_salinity_interaction'})
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5097)
```

# Iteration 89
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: streamflow_wave_interaction_7d
HYPOTHESIS: The interaction between streamflow and wave height over a 7-day window can predict enterococcus exceedance, as increased streamflow and wave activity together may mobilize and transport fecal bacteria to the beach.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest and wave_height_m for each beach, using `.rolling()` with `closed='left'` to avoid information leakage.
* Create a new column streamflow_wave_product by multiplying the 7-day rolling mean of streamflow_cfs_latest and wave_height_m.
* Group the resulting data by beach_id and calculate the standard deviation of streamflow_wave_product over the 7-day window to capture the variability of the interaction.
* Use this standard deviation as the novel feature streamflow_wave_interaction_7d, which can be used to predict enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the critical rule of selecting a column before calling rolling on a groupby object and does not use .shift()/.diff() chains off .groupby('beach_id') for 'streamflow_cfs_latest_7d_mean' and 'wave_height_m_7d_mean' calculations, and also does not follow the critical rule of selecting a column before calling rolling on a groupby object in the line where 'streamflow_wave_interaction_7d' is calculated.
```

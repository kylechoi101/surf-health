# Iteration 61
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2659 | AUCPR: 0.5095 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_anomaly_from_buoy_mean
HYPOTHESIS: The anomaly of the current wave height from the mean wave height at each beach's nearest CDIP buoy can predict enterococcus exceedance, as unusual wave patterns may mobilize fecal bacteria in the water.
IMPLEMENTATION:
* Calculate the 30-day mean wave height for each beach's nearest CDIP buoy using the `wave_height_m` column and a `.groupby()` operation on `beach_id` and a 30-day rolling window with `closed='left'`.
* Compute the anomaly of the current wave height from the 30-day mean wave height for each beach using the `wave_height_m` column and the calculated mean wave height.
* Use the `.shift()` function to ensure that the calculated mean wave height does not include the current day's wave height, avoiding information leakage.
* Multiply the wave height anomaly by the `precip_mm_6h` column to capture the interaction between unusual wave patterns and recent rainfall, which may mobilize fecal bacteria in the water.
* Handle missing values in the `wave_height_m` column using appropriate imputation or interpolation techniques to avoid biased calculations.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 30-day mean wave height for each beach's nearest CDIP buoy
    beach_day_df['mean_wave_height'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=30, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Shift the mean wave height to avoid information leakage
    beach_day_df['mean_wave_height_shifted'] = beach_day_df.groupby('beach_id')['mean_wave_height'].shift(1)
    
    # Compute the anomaly of the current wave height from the 30-day mean wave height
    beach_day_df['wave_height_anomaly_from_buoy_mean'] = (beach_day_df['wave_height_m'] - beach_day_df['mean_wave_height_shifted']) / (beach_day_df['mean_wave_height_shifted'] + 1e-9)
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_anomaly_from_buoy_mean']].copy()
    
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5107 → 0.5095)
```

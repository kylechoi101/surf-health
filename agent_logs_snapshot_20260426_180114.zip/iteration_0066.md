# Iteration 66
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_7d_by_cdip_buoy
HYPOTHESIS: The anomaly in wave height from its 7-day mean for a specific CDIP buoy is a predictor of enterococcus exceedance, as unusual wave conditions can mobilize and transport fecal bacteria into the water.
IMPLEMENTATION:
* Group beach_day_df by 'cdip_station_id' and calculate the 7-day rolling mean of 'wave_height_m' using `.rolling()` with `closed='left'`.
* Calculate the anomaly in wave height by subtracting the 7-day rolling mean from the current 'wave_height_m' value.
* Use the resulting anomaly as a feature, which will capture the deviation from typical wave conditions for each CDIP buoy.
* To handle missing values in 'wave_height_m', use `.fillna()` with a suitable replacement value, such as the mean or median wave height for the corresponding CDIP buoy.
* Ensure that the calculation is performed separately for each CDIP buoy to avoid cross-beach leakage and to capture buoy-specific wave patterns.
---
## Code
*No code generated.*

---
## Errors
```
AST FAILED: transform(lambda) is forbidden. Use named strings like transform('mean') only.
```

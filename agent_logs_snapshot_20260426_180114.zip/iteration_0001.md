# Iteration 1
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_7d_avg_anomaly
HYPOTHESIS: The anomaly in wave height over the past 7 days, compared to the historical average for that CDIP buoy, can predict enterococcus exceedance by indicating increased mobilization of fecal bacteria due to unusual wave activity.
IMPLEMENTATION:
* Calculate the 7-day average wave height for each beach using the `wave_height_m` column in `beach_day_df`, grouping by `beach_id` and `sample_date` with a 7-day rolling window.
* Calculate the historical average wave height for each CDIP buoy using the `wave_height_m` column in `beach_day_df`, grouping by `cdip_station_id` and calculating the mean over all available data.
* Calculate the anomaly in wave height for each sample by subtracting the historical average wave height for the corresponding CDIP buoy from the 7-day average wave height for that sample.
* Store the result in a new column `wave_height_7d_avg_anomaly` in `beach_day_df`, which will be used as a feature in the model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not correctly calculate the historical average wave height for each CDIP buoy, as it does not account for the 'sample_date' when calculating the historical average, and it also does not correctly calculate the 7-day average wave height for each beach, as it does not chain the .rolling() function off .groupby('beach_id').
```

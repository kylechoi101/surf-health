# Iteration 79
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating from its 30-day average wave height is a predictor of enterococcus exceedance, as unusual wave patterns can disrupt normal water circulation and increase the likelihood of bacterial contamination.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using `.groupby('beach_id').rolling('30D', closed='left').mean()`.
* Calculate the difference between the current wave_height_m and the 30-day rolling mean for each row, creating a new column wave_height_anomaly_30d.
* Handle NaN values in wave_height_m by propagating them to the wave_height_anomaly_30d column, ensuring that missing values are preserved and do not influence calculations.
* Consider using `.shift()` to align the 30-day rolling mean with the current sample date, ensuring that the calculation does not leak future data.
---
## Code
*No code generated.*

---
## Errors
```
AST FAILED: .apply() is forbidden. It runs Python per-row/group and causes timeouts. Use vectorized pandas operations.
```

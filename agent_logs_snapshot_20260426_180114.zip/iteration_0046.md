# Iteration 46
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.1862 | AUCPR: 0.5095 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_to_streamflow_ratio
HYPOTHESIS: The ratio of wave height to streamflow is likely to predict enterococcus exceedance, as high waves combined with low streamflow may indicate a lack of flushing of fecal bacteria from the surrounding environment.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach using beach_day_df and the .rolling() function with a window size of 7 and closed='left' to avoid information leakage.
* Calculate the current wave height to streamflow ratio by dividing wave_height_m by the 7-day rolling mean of streamflow_cfs_latest for each beach.
* Use the .groupby() function to calculate the ratio for each beach separately, to account for differences in streamflow and wave height across beaches.
* Handle NaN values in wave_height_m and streamflow_cfs_latest by using the .fillna() function to replace them with the median or mean of the respective column for each beach.
* Use the resulting ratio as a feature in the model, which can be computed without leaking future data and only uses per-beach aggregations.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach
    beach_day_df['streamflow_cfs_latest_7d_mean'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the current wave height to streamflow ratio
    beach_day_df['wave_height_to_streamflow_ratio'] = beach_day_df['wave_height_m'] / (beach_day_df['streamflow_cfs_latest_7d_mean'] + 1e-9)
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_to_streamflow_ratio']].copy()
    
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5095)
```

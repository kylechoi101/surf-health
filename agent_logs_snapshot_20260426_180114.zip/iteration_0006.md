# Iteration 6
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_7d
HYPOTHESIS: The deviation of current wave height from its 7-day average at the nearest CDIP buoy is a predictor of enterococcus exceedance, as anomalous wave activity can resuspend and transport fecal bacteria to the beach.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of wave_height_m for each beach_id using the sample_date, considering only the nearest CDIP buoy's data.
* Compute the anomaly as the difference between the current wave_height_m and the corresponding 7-day rolling mean.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation and subsequent difference computation.
* Use the resulting anomaly values as the novel feature wave_height_anomaly_7d, which can be used to predict enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the provided advisories_df and stations_df DataFrames, and it overwrites the original beach_day_df DataFrame by adding new columns to it.
```

# Iteration 43
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: cdip_buoy_wave_height_ratio_14d
HYPOTHESIS: A beach's current wave height relative to the 14-day average wave height of its nearest CDIP buoy is likely to mobilize fecal bacteria, increasing the risk of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each beach, grouped by the cdip_station_id from stations_df, to get the average wave height for each CDIP buoy.
* Calculate the ratio of the current wave_height_m to the 14-day average wave height for each beach, using the rolling mean calculated in the previous step.
* Handle NaN values in wave_height_m by using a forward fill or interpolation method to ensure that the ratio is calculated correctly.
* Use the resulting ratio as a feature, which will capture the anomaly in wave height for each beach relative to its nearest CDIP buoy.
---
## Code
*No code generated.*

---
## Errors
```
EXEC: Runtime error: KeyError: 'cdip_station_id'
rs/kylechoi/surf_health/backend/.venv/lib/python3.12/site-packages/pandas/core/groupby/groupby.py", line 1095, in __init__
    grouper, exclusions, obj = get_grouper(
                               ^^^^^^^^^^^^
  File "/Users/kylechoi/surf_health/backend/.venv/lib/python3.12/site-packages/pandas/core/groupby/grouper.py", line 901, in get_grouper
    raise KeyError(gpr)
KeyError: 'cdip_station_id'

```

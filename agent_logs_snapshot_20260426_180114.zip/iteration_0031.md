# Iteration 31
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_14d_by_buoy
HYPOTHESIS: A beach's current wave height exceeding its 14-day average wave height for the specific CDIP buoy it is associated with is likely to mobilize fecal bacteria and increase the risk of enterococcus exceedance.
IMPLEMENTATION:
* Group beach_day_df by cdip_station_id and calculate the 14-day rolling mean of wave_height_m for each group.
* Calculate the difference between the current wave_height_m and the 14-day rolling mean for each row.
* Use the result as the wave_height_anomaly_14d_by_buoy feature, which captures the anomaly in wave height relative to the specific buoy's recent conditions.
* To avoid information leakage, use .shift() or .diff() chains and .rolling() with closed='left' to ensure that only past data is used in the calculation.
* Handle NaN values in wave_height_m by using a suitable imputation method or by propagating NaN values through the calculation to avoid biased results.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' before applying rolling, which can cause cross-beach leakage, and also does not use 'cdip_station_id' correctly in the rolling calculation.
```

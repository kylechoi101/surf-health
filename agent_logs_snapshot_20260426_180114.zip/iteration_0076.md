# Iteration 76
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2749 | AUCPR: 0.5103 | Brier: 0.0720

---
## Idea
FEATURE NAME: precip_wave_height_interaction_7d
HYPOTHESIS: The interaction between recent precipitation and wave height is indicative of increased enterococcus exceedance due to the mobilization of fecal bacteria by combined rain and swell activity.
IMPLEMENTATION:
* Calculate the 7-day rolling sum of precip_mm_6h, precip_mm_24h, precip_mm_48h, and precip_mm_72h to capture recent precipitation events.
* Calculate the rolling mean of wave_height_m over the same 7-day window to capture recent wave activity.
* Multiply the rolling sum of precipitation by the rolling mean of wave height to create an interaction term, which will be high when both precipitation and wave height are elevated.
* Use the .groupby() function with 'beach_id' to ensure that calculations are performed separately for each beach, avoiding cross-beach leakage.
* Use the .shift() function to ensure that only past data is used in calculations, avoiding information leakage.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the sum of precipitation columns
    beach_day_df['precip_sum'] = beach_day_df[['precip_mm_6h', 'precip_mm_24h', 'precip_mm_48h', 'precip_mm_72h']].sum(axis=1)

    # Calculate the 7-day rolling sum of precipitation
    beach_day_df['precip_sum_7d'] = beach_day_df.groupby('beach_id')['precip_sum'].rolling(window=7, min_periods=1, closed='left').sum().reset_index(level=0, drop=True)

    # Calculate the 7-day rolling mean of wave height
    beach_day_df['wave_height_mean_7d'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Calculate the interaction term
    beach_day_df['precip_wave_height_interaction_7d'] = beach_day_df['precip_sum_7d'] * beach_day_df['wave_height_mean_7d']

    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'precip_wave_height_interaction_7d']].copy()
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5107 → 0.5103)
```

# Iteration 3
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_over_threshold_count
HYPOTHESIS: The number of times the wave height exceeds a certain threshold in the recent past is a predictor of enterococcus exceedance, as high wave activity can mobilize and transport fecal bacteria to the beach.
IMPLEMENTATION:
* Filter beach_day_df to only include rows where wave_height_m is greater than a certain threshold (e.g. 2 meters) and the sample_date is within the last 30 days.
* Group the filtered dataframe by beach_id and count the number of times the wave height exceeds the threshold for each beach.
* Merge the resulting count dataframe with the original beach_day_df on beach_id and sample_date.
* Use the count of wave height exceedances as a new feature, wave_height_over_threshold_count, which can be used to predict enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .shift()/.diff() chains off .groupby('beach_id') and does not use .rolling() with closed='left', but more critically, it does not prevent cross-beach leakage when calculating the wave_height_over_threshold_count, as it groups by beach_id and then merges back to the original dataframe, potentially leaking information from other beaches.
```

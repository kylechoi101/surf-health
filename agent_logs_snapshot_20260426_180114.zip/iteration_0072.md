# Iteration 72
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2292 | AUCPR: 0.5094 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_salinity_interaction
HYPOTHESIS: The interaction between a beach's current wave height and sea-surface salinity can indicate an increased risk of enterococcus exceedance due to the mobilization of fecal bacteria by unusual wave and salinity conditions.
IMPLEMENTATION:
* Calculate the product of wave_height_m and salinity_psu for each row in beach_day_df, handling NaN values in wave_height_m by replacing them with the mean wave height for the corresponding beach.
* Compute the rolling mean of this product over a 7-day window using .rolling() with closed='left' to avoid information leakage.
* Calculate the standard deviation of this product over the same 7-day window to capture the variability of the interaction between wave height and salinity.
* Use the resulting values as a feature, which can be interpreted as the average and variability of the wave height and salinity interaction over the past week.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the product of wave_height_m and salinity_psu for each row in beach_day_df
    beach_day_df['wave_height_salinity_product'] = beach_day_df['wave_height_m'].fillna(beach_day_df.groupby('beach_id')['wave_height_m'].transform('mean')) * beach_day_df['salinity_psu']

    # Compute the rolling mean of this product over a 7-day window
    beach_day_df['wave_height_salinity_mean'] = beach_day_df.groupby('beach_id')['wave_height_salinity_product'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Calculate the standard deviation of this product over the same 7-day window
    beach_day_df['wave_height_salinity_std'] = beach_day_df.groupby('beach_id')['wave_height_salinity_product'].rolling(window=7, min_periods=1, closed='left').std().reset_index(level=0, drop=True)

    # Calculate the interaction feature
    beach_day_df['wave_height_salinity_interaction'] = (beach_day_df['wave_height_salinity_product'] - beach_day_df['wave_height_salinity_mean']) / (beach_day_df['wave_height_salinity_std'] + 1e-9)

    # Return a DataFrame with columns: beach_id, sample_date, wave_height_salinity_interaction
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_salinity_interaction']]
```

---
## Errors
```
Degrades CV AUCPR (0.5107 → 0.5094)
```

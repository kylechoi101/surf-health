# Iteration 68
**Status:** FAILED (correlation gate)

---
## Idea
FEATURE NAME: streamflow_wave_height_interaction
HYPOTHESIS: A beach's enterococcus exceedance rate is higher when the current streamflow and wave height are both elevated, indicating increased mobilization and transport of fecal bacteria.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest and wave_height_m for each beach, using `.rolling()` with `closed='left'` to avoid information leakage.
* Create a new feature by multiplying the current streamflow_cfs_latest and wave_height_m values, then subtracting the product of their respective 7-day rolling means, to capture the interaction between these two variables.
* Use `.groupby()` on beach_id to ensure that the rolling means are calculated separately for each beach, and `.shift()` to align the rolling means with the current sample date.
* Handle missing values in streamflow_cfs_latest and wave_height_m by using `.fillna()` with a suitable replacement value, such as the beach-specific median or mean, to avoid propagating NaN values into the new feature.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of streamflow_cfs_latest and wave_height_m for each beach
    beach_day_df['streamflow_cfs_latest_7d_mean'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    beach_day_df['wave_height_m_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Create a new feature by multiplying the current streamflow_cfs_latest and wave_height_m values, 
    # then subtracting the product of their respective 7-day rolling means
    beach_day_df['streamflow_wave_height_interaction'] = (beach_day_df['streamflow_cfs_latest'] * beach_day_df['wave_height_m']) - (beach_day_df['streamflow_cfs_latest_7d_mean'] * beach_day_df['wave_height_m_7d_mean'])

    # Return a DataFrame with columns: beach_id, sample_date, <one_new_feature_column>
    return beach_day_df[['beach_id', 'sample_date', 'streamflow_wave_height_interaction']]
```

---
## Errors
```
High correlation (0.86) with existing features — redundant.
```

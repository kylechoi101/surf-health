# Iteration 67
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's enterococcus exceedance rate is higher when the current wave height is significantly higher than its 30-day average, indicating increased mobilization of fecal bacteria.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach, using `.groupby('beach_id').rolling('30D', closed='left')` to avoid information leakage.
* Subtract the 30-day rolling mean from the current wave_height_m to get the wave height anomaly for each sample.
* Use `.shift()` to ensure that the anomaly calculation only uses data up to the current sample date, preventing leakage of future data.
* Store the result in a new column, wave_height_anomaly_30d, which can be used as a feature in the model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not handle potential division by zero issues in the rolling mean calculation correctly, and the advisories_df and stations_df parameters are not used in the function, but more critically, the .shift() operation is applied after the calculation of wave_height_anomaly_30d which is incorrect as it should be applied before the calculation to prevent leakage of future data.
```

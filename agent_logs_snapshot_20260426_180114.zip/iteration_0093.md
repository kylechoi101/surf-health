# Iteration 93
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2480 | AUCPR: 0.5101 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_anomaly_7d_beach_mean
HYPOTHESIS: A beach's current wave height anomaly relative to its 7-day mean wave height is a predictor of enterococcus exceedance, as unusual wave patterns can mobilize fecal bacteria and increase the risk of contamination.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of wave_height_m for each beach_id, using beach_day_df, to capture the local wave pattern.
* Calculate the anomaly as the difference between the current wave_height_m and the 7-day rolling mean for each beach_id.
* Use the resulting anomaly values as a feature, which can be used to predict enterococcus exceedance, taking into account the unique wave patterns at each beach.
* Ensure that the calculation of the rolling mean only includes data up to the current sample_date, to prevent information leakage.
* Handle NaN values in wave_height_m by using a suitable imputation method, such as interpolation or using the median wave height for the beach, to ensure that the anomaly calculation is robust.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of wave_height_m for each beach_id
    beach_day_df['wave_height_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the anomaly as the difference between the current wave_height_m and the 7-day rolling mean for each beach_id
    beach_day_df['wave_height_anomaly_7d_beach_mean'] = beach_day_df['wave_height_m'] - beach_day_df['wave_height_7d_mean']
    
    # Return a DataFrame with columns: beach_id, sample_date, wave_height_anomaly_7d_beach_mean
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_anomaly_7d_beach_mean']]
```

---
## Errors
```
Degrades CV AUCPR (0.5107 → 0.5101)
```

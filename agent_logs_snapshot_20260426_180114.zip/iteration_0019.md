# Iteration 19
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: precip_wave_height_interaction_7d
HYPOTHESIS: The interaction between precipitation and wave height over the past 7 days is likely to increase the mobilization of fecal bacteria, leading to a higher enterococcus exceedance rate.
IMPLEMENTATION:
* Calculate the 7-day rolling sum of precip_mm_6h, precip_mm_24h, precip_mm_48h, and precip_mm_72h to get the total precipitation over the past 7 days.
* Calculate the 7-day rolling mean of wave_height_m to get the average wave height over the past 7 days.
* Multiply the total precipitation over the past 7 days by the average wave height over the past 7 days to get the interaction term.
* Use the resulting interaction term as a feature, which can be used to predict enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the provided advisories_df and stations_df DataFrames.
```

# Iteration 44
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_7d
HYPOTHESIS: A beach's current wave height deviating significantly from its 7-day average is likely to mobilize fecal bacteria, increasing the risk of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of wave_height_m for each beach, using `.groupby('beach_id').rolling('7d', closed='left')` to avoid information leakage.
* Compute the absolute difference between the current wave_height_m and the 7-day rolling mean, using `.subtract` to create a new column.
* Use `.shift` to ensure that the rolling mean is calculated only up to the current sample date, preventing future data from influencing the calculation.
* Consider using `.fillna` to handle NaN values in wave_height_m, replacing them with a suitable value such as the beach's historical mean wave height.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not verify that the window size passed to the rolling function is an integer, which was the main reason for the previous error.
```

# Iteration 70
**Status:** FAILED (univariate gate)

---
## Idea
FEATURE NAME: streamflow_surge_ratio_24h
HYPOTHESIS: A beach's enterococcus exceedance rate is higher when the current streamflow is significantly higher than its 24-hour baseline, indicating a potential flash-flood risk that mobilizes fecal bacteria.
IMPLEMENTATION:
* Calculate the 24-hour rolling mean of streamflow_cfs_latest for each beach_id using `.groupby()` and `.rolling()` with `closed='left'`.
* Compute the ratio of streamflow_cfs_latest to its 24-hour rolling mean, handling potential division-by-zero errors for beaches with no streamflow data.
* Use `.shift()` to ensure that the rolling mean is calculated only from previous rows, avoiding information leakage from future data.
* Clip the resulting ratio to a reasonable range (e.g., 0 to 10) to prevent extreme outliers from dominating the feature.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 24-hour rolling mean of streamflow_cfs_latest for each beach_id
    beach_day_df['streamflow_mean_24h'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].shift(1).rolling(window=24, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the ratio of streamflow_cfs_latest to its 24-hour rolling mean
    beach_day_df['streamflow_surge_ratio_24h'] = beach_day_df['streamflow_cfs_latest'] / (beach_day_df['streamflow_mean_24h'] + 1e-9)
    
    # Clip the resulting ratio to a reasonable range (e.g., 0 to 10)
    beach_day_df['streamflow_surge_ratio_24h'] = np.clip(beach_day_df['streamflow_surge_ratio_24h'], 0, 10)
    
    # Return a DataFrame with columns: beach_id, sample_date, streamflow_surge_ratio_24h
    return beach_day_df[['beach_id', 'sample_date', 'streamflow_surge_ratio_24h']]
```

---
## Errors
```
Weak standalone signal (AUCPR 0.0000 ≤ 0.15)
```

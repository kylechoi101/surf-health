# Iteration 51
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_to_salinity_ratio
HYPOTHESIS: The ratio of wave height to salinity can indicate the relative contribution of oceanic and terrestrial sources of fecal bacteria, with higher ratios potentially indicating a greater oceanic influence and lower ratios indicating a greater terrestrial influence.
IMPLEMENTATION:
* Calculate the wave height to salinity ratio by dividing the wave_height_m column by the salinity_psu column in the beach_day_df dataframe.
* Handle NaN values in the wave_height_m and salinity_psu columns by using the .fillna() method to replace them with a suitable value, such as the mean or median of the respective column.
* Use the .groupby() method to calculate the mean wave height to salinity ratio for each beach_id over a rolling window of 30 days, using the sample_date column to define the time window.
* Use the .shift() method to shift the calculated ratio back in time by one week, to ensure that the feature is computable without leaking future data.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage correctly, as the rolling function is not properly chained off a groupby object with a selected column, and the function also does not use the advisories_df and stations_df parameters.
```

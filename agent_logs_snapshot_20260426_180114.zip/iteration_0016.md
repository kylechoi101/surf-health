# Iteration 16
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2628 | AUCPR: 0.5098 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: A beach's current wave height deviating significantly from the mean wave height of its nearest CDIP buoy over a 30-day period may indicate an increased risk of enterococcus exceedance due to the mobilization of fecal bacteria by unusual wave patterns.
IMPLEMENTATION:
* Group beach_day_df by 'cdip_station_id' and calculate the 30-day rolling mean of 'wave_height_m' for each buoy using `.rolling()` with `closed='left'`.
* Calculate the deviation of the current 'wave_height_m' from the 30-day rolling mean for each buoy using `.shift()` or `.diff()` chains.
* Merge the resulting deviation values back into beach_day_df using the 'cdip_station_id' column.
* Handle missing 'wave_height_m' values by propagating NaN values through the rolling mean and deviation calculations to avoid introducing bias.
* Consider using `.groupby()` and `.apply()` to apply the rolling mean and deviation calculations to each buoy's data separately, ensuring that the calculations are performed within each buoy's data without leaking information across buoys.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Merge beach_day_df with stations_df to get cdip_station_id
    merged_df = pd.merge(beach_day_df, stations_df[['beach_id', 'cdip_station_id']], on='beach_id')
    
    # Group by 'beach_id' and calculate the 30-day rolling mean of 'wave_height_m'
    merged_df['rolling_mean_wave_height'] = merged_df.groupby('beach_id')['wave_height_m'].rolling(window=30, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the deviation of the current 'wave_height_m' from the 30-day rolling mean
    merged_df['wave_height_deviation_from_buoy_mean'] = (merged_df['wave_height_m'] - merged_df['rolling_mean_wave_height']) / (merged_df['rolling_mean_wave_height'] + 1e-9)
    
    # Select the required columns and return the result
    result_df = merged_df[['beach_id', 'sample_date', 'wave_height_deviation_from_buoy_mean']]
    
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5098)
```

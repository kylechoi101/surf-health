# Iteration 34
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2519 | AUCPR: 0.5096 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_anomaly_7d
HYPOTHESIS: A beach's current wave height deviating significantly from its 7-day average wave height, as measured by the nearest CDIP buoy, may indicate increased mobilization of fecal bacteria and thus predict enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of wave_height_m for each beach_id using `.groupby()` and `.rolling()` with `closed='left'`.
* Compute the difference between the current wave_height_m and the 7-day rolling mean for each beach_id.
* Use `.shift()` to align the 7-day rolling mean with the current wave_height_m, avoiding information leakage.
* Scale the anomaly values using a robust scaling method, such as the interquartile range (IQR), to reduce the impact of extreme values.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of wave_height_m for each beach_id
    beach_day_df['wave_height_m_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the difference between the current wave_height_m and the 7-day rolling mean for each beach_id
    beach_day_df['wave_height_m_diff'] = beach_day_df['wave_height_m'] - beach_day_df['wave_height_m_7d_mean']
    
    # Use .shift() to align the 7-day rolling mean with the current wave_height_m, avoiding information leakage
    beach_day_df['wave_height_m_diff_shifted'] = beach_day_df.groupby('beach_id')['wave_height_m_diff'].shift(1)
    
    # Scale the anomaly values using the interquartile range (IQR) to reduce the impact of extreme values
    beach_day_df['wave_height_m_diff_shifted_iqr'] = beach_day_df.groupby('beach_id')['wave_height_m_diff_shifted'].transform('quantile', 0.75) - beach_day_df.groupby('beach_id')['wave_height_m_diff_shifted'].transform('quantile', 0.25)
    beach_day_df['wave_height_anomaly_7d'] = beach_day_df['wave_height_m_diff_shifted'] / (beach_day_df['wave_height_m_diff_shifted_iqr'] + 1e-9)
    
    # Return a DataFrame with columns: beach_id, sample_date, wave_height_anomaly_7d
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_anomaly_7d']]
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5096)
```

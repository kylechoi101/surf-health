# Iteration 85
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_salinity_interaction
HYPOTHESIS: The interaction between wave height and salinity can indicate the mobilization of fecal bacteria, as increased wave energy can resuspend sediment and bacteria, while lower salinity can signal freshwater input and increased bacterial loads.
IMPLEMENTATION:
* Calculate the product of wave_height_m and salinity_psu for each row in beach_day_df to capture the interaction between these two variables.
* Use the .fillna() method to replace NaN values in wave_height_m with the median wave height for the corresponding CDIP buoy, calculated from the non-missing values in the same beach_id group.
* Apply a per-beach standardization to the resulting interaction values, subtracting the mean and dividing by the standard deviation for each beach_id, to account for differences in wave and salinity regimes across beaches.
* Consider using a rolling window (e.g., 7-day) to calculate the mean and standard deviation for each beach, to capture temporal variations in the interaction between wave height and salinity.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The standardization step incorrectly subtracts the mean from the interaction values, it should subtract the mean from the interaction values before dividing by the standard deviation. The correct line should be: `beach_day_df['wave_height_salinity_interaction'] = (beach_day_df['wave_height_salinity_interaction'] - beach_day_df.groupby('beach_id')['wave_height_salinity_interaction'].transform('mean')) / (beach_day_df.groupby('beach_id')['wave_height_salinity_interaction'].transform('std') + 1e-9)`.
```

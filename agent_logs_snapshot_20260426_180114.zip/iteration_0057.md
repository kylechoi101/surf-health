# Iteration 57
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_from_30d_mean_by_buoy
HYPOTHESIS: The anomaly of the current wave height from the 30-day mean wave height at the same CDIP buoy can predict enterococcus exceedance, as unusually high waves may mobilize and transport fecal bacteria to the beach.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy, using beach_day_df and grouping by cdip_station_id.
* Compute the anomaly of the current wave height from this rolling mean, by subtracting the rolling mean from wave_height_m.
* Use the resulting anomaly as a feature, which captures the deviation of the current wave height from the typical wave height at the same buoy.
* Consider using a robust measure of central tendency, such as the median, to reduce the impact of extreme wave height values on the rolling mean.
* Ensure that the rolling mean calculation uses a suitable window alignment, such as 'left' or 'right', to avoid information leakage and ensure that only past data is used to compute the feature.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not follow the critical rule of chaining window functions off .groupby('beach_id'), instead it groups by 'cdip_station_id'.
```

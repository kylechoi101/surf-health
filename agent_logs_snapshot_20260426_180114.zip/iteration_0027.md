# Iteration 27
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_salinity_interaction
HYPOTHESIS: The interaction between wave height and salinity can predict enterococcus exceedance by indicating the mobilization of fecal bacteria from sediment and runoff into the water column, where changes in wave energy and freshwater input can enhance bacterial transport and survival.
IMPLEMENTATION:
* Calculate the product of wave_height_m and salinity_psu for each row in beach_day_df to capture the interaction between wave energy and freshwater input.
* Use the .groupby() function to calculate the mean and standard deviation of this product for each beach_id, allowing for beach-specific characterization of this interaction.
* Calculate the anomaly of this product for each row by subtracting the mean and dividing by the standard deviation for that beach_id, providing a normalized measure of the interaction that can be compared across beaches.
* Consider using a rolling window (e.g., 14 days) to calculate a moving average of this anomaly, allowing for the capture of recent changes in the wave height-salinity interaction that may influence enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage for the calculation of the mean and standard deviation of the product, and the new feature column name does not follow the naming convention.
```

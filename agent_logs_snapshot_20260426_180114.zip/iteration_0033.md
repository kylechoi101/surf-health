# Iteration 33
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating significantly from its 30-day average wave height, as measured by the nearest CDIP buoy, may indicate increased mobilization of fecal bacteria and thus predict enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using `.groupby('beach_id').rolling('30D', closed='left')`.
* Compute the anomaly as the difference between the current wave_height_m and the corresponding 30-day rolling mean.
* Use `.shift()` to align the anomaly values with their corresponding sample_date, ensuring that no future data is used.
* Store the result in a new column, wave_height_anomaly_30d, which will be used as a feature in the model.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function uses .shift(0) which is unnecessary and does not follow the required pattern for preventing cross-beach leakage, and also the .shift() function should be chained off .groupby('beach_id') to prevent cross-beach leakage.
```

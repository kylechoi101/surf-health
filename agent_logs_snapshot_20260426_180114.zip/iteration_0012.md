# Iteration 12
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2516 | AUCPR: 0.5102 | Brier: 0.0720

---
## Idea
FEATURE NAME: wave_height_anomaly_14d
HYPOTHESIS: A wave height anomaly over the past 14 days may indicate increased resuspension of fecal bacteria, leading to a higher likelihood of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each beach_id, using `.groupby('beach_id').rolling(14, min_periods=1, closed='left')` to avoid information leakage.
* Compute the anomaly by subtracting the rolling mean from the current wave_height_m value, creating a new column with the result.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation and subsequent anomaly computation, ensuring that NaN values in the input data result in NaN values in the output feature.
* Consider using `.shift()` to align the rolling mean with the current sample date, ensuring that the anomaly calculation only uses data from the past 14 days.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    """
    This function engineers a novel beach water-quality feature, 
    wave_height_anomaly_14d, which is the anomaly of wave height over the past 14 days.
    
    Parameters:
    beach_day_df (DataFrame): A DataFrame containing beach day data.
    advisories_df (DataFrame): A DataFrame containing advisories data.
    stations_df (DataFrame): A DataFrame containing stations data.
    
    Returns:
    DataFrame: A DataFrame with columns: beach_id, sample_date, wave_height_anomaly_14d.
    """
    
    # Calculate the 14-day rolling mean of wave_height_m for each beach_id
    beach_day_df['wave_height_m_rolling_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(14, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the anomaly by subtracting the rolling mean from the current wave_height_m value
    beach_day_df['wave_height_anomaly_14d'] = beach_day_df['wave_height_m'] - beach_day_df['wave_height_m_rolling_mean']
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_anomaly_14d']]
    
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5102)
```

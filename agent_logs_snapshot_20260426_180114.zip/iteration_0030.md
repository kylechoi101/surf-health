# Iteration 30
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_14d_buoy_relative
HYPOTHESIS: A beach's current wave height exceeding its 14-day average wave height at the nearest CDIP buoy is likely to mobilize fecal bacteria and increase the risk of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each cdip_station_id (not beach_id) to account for shared buoys across beaches
* For each row in beach_day_df, find the corresponding 14-day rolling mean wave height at the nearest CDIP buoy (using cdip_station_id)
* Calculate the anomaly as the difference between the current wave_height_m and the 14-day rolling mean wave height at the buoy
* Handle NaN values in wave_height_m by using a forward fill or interpolation to ensure the anomaly calculation is accurate and doesn't propagate NaN values.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .groupby('beach_id') for .rolling() and instead uses .groupby('cdip_station_id') which may cause cross-beach leakage.
```

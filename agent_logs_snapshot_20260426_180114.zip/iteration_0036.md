# Iteration 36
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.1991 | AUCPR: 0.5091 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_salinity_interaction
HYPOTHESIS: The interaction between wave height and salinity at a beach may predict enterococcus exceedance, as increased wave energy and changes in salinity can mobilize and concentrate fecal bacteria in the water.
IMPLEMENTATION:
* Calculate the product of wave_height_m and salinity_psu for each row in beach_day_df to capture the interaction between these two variables.
* Use the .fillna() method to replace NaN values in wave_height_m with the median wave height for the corresponding beach, to avoid losing data due to missing values.
* Group the data by beach_id and calculate the rolling mean of the wave height-salinity product over a 14-day window using .rolling() with a closed='left' argument, to capture recent changes in this interaction.
* Calculate the difference between the current wave height-salinity product and its rolling mean, to identify deviations from the recent trend that may indicate increased risk of enterococcus exceedance.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Replace NaN values in wave_height_m with the median wave height for the corresponding beach
    beach_day_df['wave_height_m'] = beach_day_df.groupby('beach_id')['wave_height_m'].transform('median')

    # Calculate the product of wave_height_m and salinity_psu for each row
    beach_day_df['wave_height_salinity_product'] = beach_day_df['wave_height_m'] * beach_day_df['salinity_psu']

    # Group the data by beach_id and calculate the rolling mean of the wave height-salinity product over a 14-day window
    beach_day_df['wave_height_salinity_interaction'] = beach_day_df.groupby('beach_id')['wave_height_salinity_product'].rolling(window=14, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_salinity_interaction']].copy()
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5091)
```

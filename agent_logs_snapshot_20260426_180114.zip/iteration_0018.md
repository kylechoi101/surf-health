# Iteration 18
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_14d
HYPOTHESIS: A beach's current wave height exceeding its 14-day average wave height is likely to increase the mobilization of fecal bacteria, leading to a higher enterococcus exceedance rate.
IMPLEMENTATION:
* Calculate the 14-day rolling mean of wave_height_m for each beach, using `.groupby('beach_id').rolling(14, closed='left')` to avoid information leakage.
* Compute the difference between the current wave_height_m and the 14-day rolling mean, creating a new column wave_height_anomaly_14d.
* Handle NaN values in wave_height_m by using `.fillna()` with a suitable replacement value, such as the beach's overall mean wave height, to ensure that the anomaly calculation is robust.
* Use `.shift()` to align the rolling mean with the current sample date, ensuring that the feature is computable without leaking future data.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not correctly fill NaN values in the 'wave_height_m' column, as it uses the mean of the group and then fills NaN values with the original column, which still contains NaN values.
```

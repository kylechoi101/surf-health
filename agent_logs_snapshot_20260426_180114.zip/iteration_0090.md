# Iteration 90
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2361 | AUCPR: 0.5104 | Brier: 0.0720

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean_30d
HYPOTHESIS: The deviation of the current wave height from its 30-day mean for a specific CDIP buoy can predict enterococcus exceedance, as unusual wave patterns may mobilize fecal bacteria.
IMPLEMENTATION:
* Group beach_day_df by 'cdip_station_id' and calculate the 30-day rolling mean of 'wave_height_m' using `.rolling()` with `closed='left'` to avoid information leakage.
* Calculate the deviation of the current 'wave_height_m' from the 30-day rolling mean for each CDIP buoy.
* Use `.shift()` to ensure that the calculation only uses data up to the current sample date, avoiding any future data leakage.
* Merge the resulting deviation values back into beach_day_df to create the novel feature.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 30-day rolling mean of 'wave_height_m' for each CDIP buoy
    beach_day_df['wave_height_30d_mean'] = beach_day_df.groupby('cdip_station_id')['wave_height_m'].rolling(window=30, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Calculate the deviation of the current 'wave_height_m' from the 30-day rolling mean for each CDIP buoy
    beach_day_df['wave_height_deviation_from_buoy_mean_30d'] = beach_day_df['wave_height_m'] - beach_day_df['wave_height_30d_mean']
    
    # Shift the deviation values to avoid any future data leakage
    beach_day_df['wave_height_deviation_from_buoy_mean_30d'] = beach_day_df.groupby('cdip_station_id')['wave_height_deviation_from_buoy_mean_30d'].shift(1)
    
    # Select the required columns and return the resulting DataFrame
    return beach_day_df[['beach_id', 'sample_date', 'wave_height_deviation_from_buoy_mean_30d']]
```

---
## Errors
```
Degrades CV AUCPR (0.5107 → 0.5104)
```

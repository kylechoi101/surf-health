# Iteration 71
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating significantly from its 30-day average wave height, as measured by the nearest CDIP buoy, can indicate an increased risk of enterococcus exceedance due to the mobilization of fecal bacteria by unusual wave activity.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach, using `.groupby('beach_id').rolling('30D', closed='left')` to avoid information leakage.
* Compute the absolute difference between the current wave_height_m and the 30-day rolling mean, using `.sub()` to create a new column.
* Use `.shift()` to ensure that the rolling mean calculation only uses data up to the current sample date, avoiding any potential leakage of future data.
* Divide the result by the 30-day rolling standard deviation of wave_height_m to normalize the anomaly, allowing for comparison across different beaches and time periods.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the provided advisories_df and stations_df DataFrames, and it incorrectly uses reset_index which can cause cross-beach leakage.
```

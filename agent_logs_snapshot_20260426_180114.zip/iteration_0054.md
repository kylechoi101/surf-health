# Iteration 54
**Status:** SUCCESS
**Metrics:** Uni: 0.2978 | AUCPR: 0.5107 (+0.0001) | Brier: 0.0720 (-0.0000)

---
## Idea
FEATURE NAME: streamflow_spike_ratio_7d
HYPOTHESIS: A rapid increase in streamflow, indicated by a high ratio of the latest streamflow to the 7-day average, is likely to mobilize fecal bacteria and increase the enterococcus exceedance rate.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach_id using `.groupby()` and `.rolling()`.
* Compute the ratio of streamflow_cfs_latest to the 7-day rolling mean for each row in beach_day_df.
* Use `.shift()` to ensure that the calculation only uses data up to the current sample_date, avoiding information leakage.
* Clip the ratio to a reasonable range (e.g., 0 to 10) to prevent extreme values from dominating the feature.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach_id
    beach_day_df['streamflow_cfs_7d_mean'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the ratio of streamflow_cfs_latest to the 7-day rolling mean for each row
    beach_day_df['streamflow_spike_ratio_7d'] = beach_day_df['streamflow_cfs_latest'] / (beach_day_df['streamflow_cfs_7d_mean'] + 1e-9)
    
    # Clip the ratio to a reasonable range (e.g., 0 to 10)
    beach_day_df['streamflow_spike_ratio_7d'] = np.clip(beach_day_df['streamflow_spike_ratio_7d'], 0, 10)
    
    # Shift the ratio to prevent current-sample leakage
    beach_day_df['streamflow_spike_ratio_7d_shifted'] = beach_day_df.groupby('beach_id')['streamflow_spike_ratio_7d'].shift(1)
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'streamflow_spike_ratio_7d_shifted']].rename(columns={'streamflow_spike_ratio_7d_shifted': 'streamflow_spike_ratio_7d'})
    
    return result_df
```

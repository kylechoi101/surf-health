# Iteration 53
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height exceeding its 30-day average wave height is likely to increase the mobilization of fecal bacteria, leading to a higher enterococcus exceedance rate.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach, using `beach_day_df.groupby('beach_id')['wave_height_m'].transform(lambda x: x.rolling('30D', closed='left').mean())`.
* Calculate the anomaly by subtracting the 30-day rolling mean from the current wave_height_m, `wave_height_m - wave_height_m_30d_mean`.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation, ensuring that the anomaly is also NaN when the wave height is missing.
* Use the resulting wave_height_anomaly_30d as a feature, which represents the deviation of the current wave height from its recent average, potentially indicating an increased risk of enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use the provided advisories_df and stations_df DataFrames, and it does not follow the critical rule of selecting a column before calling rolling on a groupby object in the exact chain specified, instead it uses reset_index which is not necessary and can be avoided by selecting the column first.
```

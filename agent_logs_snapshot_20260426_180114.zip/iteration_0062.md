# Iteration 62
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: The deviation of the current wave height from the mean wave height at each beach's nearest CDIP buoy can predict enterococcus exceedance, as unusual wave patterns may mobilize fecal bacteria in the water.
IMPLEMENTATION:
* Group beach_day_df by 'cdip_station_id' and calculate the mean 'wave_height_m' for each group using a 30-day rolling window with 'sample_date' as the index.
* Calculate the deviation of the current 'wave_height_m' from the mean 'wave_height_m' for each group using the rolling window mean.
* Handle NaN values in 'wave_height_m' by filling them with the mean 'wave_height_m' for each 'cdip_station_id' group.
* Use the '.shift()' function to ensure that the calculated deviation does not leak future data, by shifting the deviation values to match the 'sample_date' index.
* Merge the calculated deviation with the original beach_day_df to create the new feature 'wave_height_deviation_from_buoy_mean'.
---
## Code
*No code generated.*

---
## Errors
```
AST FAILED: transform(lambda) is forbidden. Use named strings like transform('mean') only.
```

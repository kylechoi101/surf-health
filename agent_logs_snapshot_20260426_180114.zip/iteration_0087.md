# Iteration 87
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: The deviation of the current wave height from its 30-day mean for a specific CDIP buoy can predict enterococcus exceedance, as unusual wave patterns may mobilize fecal bacteria.
IMPLEMENTATION:
* Group beach_day_df by 'cdip_station_id' and calculate the 30-day rolling mean of 'wave_height_m' using `.rolling()` with `closed='left'`.
* Calculate the anomaly by subtracting the rolling mean from the current 'wave_height_m' value.
* Handle NaN values in 'wave_height_m' by using `.fillna()` or `.interpolate()` methods to avoid introducing bias in the feature calculation.
* Store the resulting wave height anomaly values in a new column 'wave_height_anomaly_30d' in beach_day_df.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not group by 'beach_id' or 'cdip_station_id' when calculating the rolling mean of 'wave_height_m' after filling NaN values, which could cause cross-beach leakage.
```

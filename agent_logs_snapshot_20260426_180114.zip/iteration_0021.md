# Iteration 21
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: The deviation of current wave height from the 30-day average wave height for the nearest CDIP buoy can indicate increased mobilization of fecal bacteria, leading to enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id, using `.groupby('beach_id').rolling(30, closed='left')` to avoid information leakage.
* Compute the anomaly by subtracting the 30-day rolling mean from the current wave_height_m, using `.sub()` method.
* Handle NaN values in wave_height_m by propagating them through the rolling mean and anomaly calculations, ensuring that NaNs are preserved in the resulting feature.
* Consider using `.min_periods=1` in the rolling mean calculation to include the first 29 days of data for each beach, even if the rolling window is not fully populated.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .shift()/.diff() chains off .groupby('beach_id') as required, instead it uses .rolling() directly on the grouped column, and also does not follow the required chain for .rolling() to prevent cross-beach leakage.
```

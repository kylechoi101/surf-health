# Iteration 10
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_deviation_from_buoy_mean
HYPOTHESIS: A beach's current wave height compared to the average wave height of its corresponding CDIP buoy over the last 30 days can indicate increased mobilization of fecal bacteria, leading to a higher likelihood of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each CDIP buoy, grouping by cdip_station_id in beach_day_df.
* Merge the resulting buoy-level rolling means with beach_day_df on cdip_station_id to create a new column, buoy_mean_wave_height.
* Calculate the deviation of wave_height_m from the corresponding buoy_mean_wave_height for each row in beach_day_df.
* Use this deviation as the novel feature, wave_height_deviation_from_buoy_mean, to capture the anomaly in wave height relative to the buoy's average condition.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not prevent cross-beach leakage by using .groupby('cdip_station_id') for the rolling window operation, instead it should use .groupby('beach_id') to prevent leakage between different beaches.
```

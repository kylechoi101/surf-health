# Iteration 37
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2251 | AUCPR: 0.5097 | Brier: 0.0721

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating significantly from its 30-day average may indicate increased mobilization of fecal bacteria, leading to a higher likelihood of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id using `.groupby()` and `.rolling()` with a 30-day window and `closed='left'` to avoid information leakage.
* Compute the absolute difference between the current wave_height_m and the 30-day rolling mean for each row, storing this in a new column.
* Handle NaN values in wave_height_m by propagating them through the rolling mean calculation and subsequent difference computation, ensuring that NaNs in the input data result in NaNs in the output feature.
* Consider using `.shift()` to align the rolling mean calculation with the current sample date, ensuring that only past data is used in the feature computation.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 30-day rolling mean of wave_height_m for each beach_id
    beach_day_df['wave_height_m_30d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=30, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)
    
    # Compute the absolute difference between the current wave_height_m and the 30-day rolling mean for each row
    beach_day_df['wave_height_anomaly_30d'] = (beach_day_df['wave_height_m'] - beach_day_df['wave_height_m_30d_mean']).abs()
    
    # Select the required columns and return the result
    result_df = beach_day_df[['beach_id', 'sample_date', 'wave_height_anomaly_30d']]
    
    return result_df
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5097)
```

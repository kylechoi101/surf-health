# Iteration 7
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height compared to its 30-day average wave height can indicate increased mobilization of fecal bacteria, leading to a higher likelihood of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id, using .groupby('beach_id') and .rolling('30D', closed='left') to avoid information leakage.
* Subtract the rolling mean from the current wave_height_m to obtain the wave height anomaly for each sample.
* Use .fillna(0) to handle NaN values in wave_height_m, assuming no wave height anomaly when data is missing.
* Consider applying a .clip() function to limit the anomaly values to a reasonable range, preventing extreme values from dominating the feature.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not handle potential division by zero in the rolling mean calculation and does not check for potential errors in the input dataframes, also it does not use the advisories_df and stations_df parameters.
```

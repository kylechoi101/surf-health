# Iteration 4
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_times_precip
HYPOTHESIS: The product of wave height and precipitation in the recent past is a predictor of enterococcus exceedance, as the combination of heavy rainfall and high wave activity can mobilize and transport large amounts of fecal bacteria to the beach.
IMPLEMENTATION:
* Filter beach_day_df to include only rows where precip_mm_6h is greater than 0, indicating recent rainfall.
* Calculate the product of wave_height_m and precip_mm_6h for each row, creating a new column representing the interaction between wave height and precipitation.
* Calculate the 7-day moving average of this product for each beach, using the sample_date column to determine the time window.
* Merge this new feature with the original beach_day_df, using beach_id and sample_date to match rows, and use this feature as a predictor of enterococcus exceedance.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not correctly implement the rolling average calculation after filtering for precipitation and does not use .shift()/.diff() chains off .groupby('beach_id') as specified in the critical rules for pandas.
```

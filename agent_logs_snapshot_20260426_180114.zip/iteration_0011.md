# Iteration 11
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: wave_height_anomaly_30d
HYPOTHESIS: A beach's current wave height deviating significantly from its 30-day average wave height, as measured by the nearest CDIP buoy, may indicate increased mobilization of fecal bacteria, leading to a higher likelihood of enterococcus exceedance.
IMPLEMENTATION:
* Calculate the 30-day rolling mean of wave_height_m for each beach_id, using .groupby('beach_id') and .rolling('30D', closed='left') to prevent information leakage.
* Calculate the difference between the current wave_height_m and the 30-day rolling mean, creating a new column wave_height_anomaly_30d.
* Handle NaN values in wave_height_m by using .fillna(0) or .interpolate() to avoid propagating NaN values to the wave_height_anomaly_30d column.
* Consider using .shift() to align the wave_height_anomaly_30d with the sample_date, ensuring that the anomaly is calculated based on data prior to the sample date.
* Use the resulting wave_height_anomaly_30d column as a feature in the model, potentially scaling or transforming it to improve its predictive power.
---
## Code
*No code generated.*

---
## Errors
```
CRITIC: The function does not use .shift()/.diff() chains off .groupby('beach_id') as required, instead it uses .rolling() directly on the grouped object which may cause cross-beach leakage if not properly reset.
```

# Iteration 39
**Status:** FAILED (CV gate)
**Metrics:** Uni: 0.2669 | AUCPR: 0.5100 | Brier: 0.0720

---
## Idea
FEATURE NAME: streamflow_wave_height_interaction
HYPOTHESIS: The interaction between streamflow and wave height may indicate increased mobilization of fecal bacteria, leading to a higher likelihood of enterococcus exceedance, as heavy rainfall and strong waves can combine to resuspend and transport bacteria into the water.
IMPLEMENTATION:
* Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach using `beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].transform(lambda x: x.rolling(7, min_periods=1).mean())`
* Calculate the 7-day rolling mean of wave_height_m for each beach using `beach_day_df.groupby('beach_id')['wave_height_m'].transform(lambda x: x.rolling(7, min_periods=1).mean())`
* Create a new feature by multiplying the standardized streamflow and wave height values for each sample, using `beach_day_df['streamflow_wave_height_interaction'] = (beach_day_df['streamflow_cfs_latest'] / beach_day_df['streamflow_cfs_latest'].rolling(7, min_periods=1).mean()) * (beach_day_df['wave_height_m'] / beach_day_df['wave_height_m'].rolling(7, min_periods=1).mean())`
* Handle NaN values by filling with the beach-specific mean or median of the interaction feature, using `beach_day_df['streamflow_wave_height_interaction'].fillna(beach_day_df.groupby('beach_id')['streamflow_wave_height_interaction'].transform('mean'))`
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    # Calculate the 7-day rolling mean of streamflow_cfs_latest for each beach
    beach_day_df['streamflow_cfs_latest_7d_mean'] = beach_day_df.groupby('beach_id')['streamflow_cfs_latest'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Calculate the 7-day rolling mean of wave_height_m for each beach
    beach_day_df['wave_height_m_7d_mean'] = beach_day_df.groupby('beach_id')['wave_height_m'].rolling(window=7, min_periods=1, closed='left').mean().reset_index(level=0, drop=True)

    # Standardize streamflow and wave height
    beach_day_df['streamflow_cfs_latest_7d_mean_std'] = (beach_day_df['streamflow_cfs_latest_7d_mean'] - beach_day_df.groupby('beach_id')['streamflow_cfs_latest_7d_mean'].transform('mean')) / (beach_day_df.groupby('beach_id')['streamflow_cfs_latest_7d_mean'].transform('std') + 1e-9)
    beach_day_df['wave_height_m_7d_mean_std'] = (beach_day_df['wave_height_m_7d_mean'] - beach_day_df.groupby('beach_id')['wave_height_m_7d_mean'].transform('mean')) / (beach_day_df.groupby('beach_id')['wave_height_m_7d_mean'].transform('std') + 1e-9)

    # Create a new feature by multiplying the standardized streamflow and wave height
    beach_day_df['streamflow_wave_height_interaction'] = beach_day_df['streamflow_cfs_latest_7d_mean_std'] * beach_day_df['wave_height_m_7d_mean_std']

    # Return a DataFrame with columns: beach_id, sample_date, <one_new_feature_column>
    return beach_day_df[['beach_id', 'sample_date', 'streamflow_wave_height_interaction']]
```

---
## Errors
```
Degrades CV AUCPR (0.5105 → 0.5100)
```

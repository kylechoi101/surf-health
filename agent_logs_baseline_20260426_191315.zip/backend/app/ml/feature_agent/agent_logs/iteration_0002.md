# Iteration 2
**Status:** SUCCESS
**Metrics:** Uni: 0.2124 | AUCPR: 0.5105 (+0.0000) | Brier: 0.0720 (+0.0000)

---
## Idea
FEATURE NAME: runoff_dispersion_index

HYPOTHESIS: Enterococcus concentrations increase when high freshwater delivery (streamflow) coincides with low wave energy, as low-energy conditions prevent the contaminated plume from being dispersed offshore and instead allow it to linger in the swimming zone.

IMPLEMENTATION:
- Compute a wave energy proxy by multiplying `wave_height_m` and `dominant_period_s`.
- Create a ratio by dividing `streamflow_cfs_latest` by this wave energy proxy, adding a small constant (e.g., 0.01) to the denominator to prevent division by zero.
- Multiply this ratio by the `first_flush_flag` to weight the feature toward the high-risk period immediately following a dry spell.
- Fill any resulting NaN values with 0.0 to represent periods of no runoff or missing buoy data.
---
## Code
```python
import pandas as pd
import numpy as np

def build_novel_feature(beach_day_df, advisories_df, stations_df, **kwargs):
    """
    Engineers the runoff_dispersion_index feature based on the hypothesis that 
    Enterococcus concentrations increase when high freshwater delivery coincides 
    with low wave energy.
    """
    # Compute a wave energy proxy by multiplying wave height and dominant period
    wave_energy_proxy = beach_day_df['wave_height_m'] * beach_day_df['dominant_period_s']
    
    # Create a ratio of streamflow to wave energy
    # Adding 0.01 to the denominator as per the specific implementation spec to prevent division by zero
    ratio = beach_day_df['streamflow_cfs_latest'] / (wave_energy_proxy + 0.01)
    
    # Multiply the ratio by the first_flush_flag to weight the feature toward high-risk periods
    # Fill resulting NaN values with 0.0 to represent periods of no runoff or missing buoy data
    rdf = (ratio * beach_day_df['first_flush_flag']).fillna(0.0)
    
    # Construct the output DataFrame with only the required columns
    # sample_date is preserved as datetime from the original beach_day_df
    result = beach_day_df[['beach_id', 'sample_date']].copy()
    result['runoff_dispersion_index'] = rdf
    
    return result
```

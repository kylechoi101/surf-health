# Iteration 1
**Status:** FAILED (code/exec)

---
## Idea
FEATURE NAME: freshwater_plume_intensity

HYPOTHESIS: A significant drop in salinity relative to a beach's local baseline, amplified by high streamflow and proximity to the pour point, indicates the arrival of a contaminated freshwater plume.

IMPLEMENTATION:
- Group `beach_day_df` by `beach_id` and calculate a trailing 30-day rolling mean of `salinity_psu` to establish a site-specific baseline.
- Calculate the salinity deficit by subtracting the current `salinity_psu` from this rolling mean.
- Multiply the salinity deficit by `streamflow_cfs_latest` to weigh the salinity drop by the volume of water being discharged.
- Divide the result by (`distance_to_pour_point_km` + 0.1) to account for the fact that beaches closer to the river mouth are more susceptible to plume impacts.
- Fill any resulting NaN values with 0 to handle cases where salinity or streamflow data is missing.
---
## Code
*No code generated.*

---
## Errors
```
EXEC: Runtime error: ValueError: cannot reindex on an axis with duplicate labels
-packages/pandas/core/generic.py", line 5498, in _reindex_axes
    new_index, indexer = ax.reindex(
                         ^^^^^^^^^^^
  File "/Users/kylechoi/surf_health/backend/.venv/lib/python3.12/site-packages/pandas/core/indexes/base.py", line 4253, in reindex
    raise ValueError("cannot reindex on an axis with duplicate labels")
ValueError: cannot reindex on an axis with duplicate labels

```
